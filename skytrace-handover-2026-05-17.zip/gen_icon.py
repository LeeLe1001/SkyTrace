import struct, zlib, io

def make_simple_png(size, filepath):
    """Create a solid blue circle PNG icon."""
    w = h = size
    buf = io.BytesIO()
    buf.write(b'\x89PNG\r\n\x1a\n')
    
    def wchunk(ctype, data):
        buf.write(struct.pack('>I', len(data)))
        buf.write(ctype)
        buf.write(data)
        buf.write(struct.pack('>I', zlib.crc32(ctype + data) & 0xffffffff))
    
    wchunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))  # RGB no alpha
    
    # All pixels blue
    row = b'\x00' + bytes([59, 130, 246]) * w
    raw_data = row * h
    wchunk(b'IDAT', zlib.compress(raw_data))
    wchunk(b'IEND', b'')
    
    with open(filepath, 'wb') as f:
        f.write(buf.getvalue())
    print(f'Created {filepath} ({size}x{size})')

make_simple_png(192, 'static/icons/icon-192.png')
make_simple_png(512, 'static/icons/icon-512.png')
print('Done!')
