"""验证所有新功能"""
import urllib.request, json

BASE = 'http://127.0.0.1:5000'

def test(name, url, check_fn):
    try:
        r = urllib.request.urlopen(url)
        data = r.read().decode()
        result = check_fn(data)
        print(f"  ✅ {name}: {result}")
        return True
    except Exception as e:
        print(f"  ❌ {name}: {e}")
        return False

print("=== SkyTrace Feature Verification ===\n")

# 1. Flights API
test("Flights API", f"{BASE}/api/flights",
     lambda d: f"{len(json.loads(d))} flights")

# 2. Stats API
test("Stats API", f"{BASE}/api/stats",
     lambda d: f"flights={json.loads(d)['total_flights']}, years={json.loads(d).get('available_years',[])}")

# 3. Stats year filter
test("Stats Year Filter", f"{BASE}/api/stats?year=2025",
     lambda d: f"2025 flights={json.loads(d)['total_flights']}")

# 4. Stats detail data (weekday_flights, month_flights)
def check_detail(d):
    s = json.loads(d)
    fun = s.get('fun_stats', {})
    wf = fun.get('weekday_flights', [])
    mf = fun.get('month_flights', {})
    return f"weekday_flights={len(wf)} days, month_flights={len(mf)} months"
test("Stats Detail Data", f"{BASE}/api/stats", check_detail)

# 5. Service Worker route
test("Service Worker", f"{BASE}/sw.js",
     lambda d: f"OK (length={len(d)}, has CACHE_NAME={'CACHE_NAME' in d})")

# 6. HTML checks
def check_html(d):
    checks = {
        'manifest.json': 'manifest.json' in d,
        'apple-pwa': 'apple-mobile-web-app-capable' in d,
        'modal-back': 'modal-back' in d,
        'dep-gate field': 'id="dep-gate"' in d,
        'arr-gate field': 'id="arr-gate"' in d,
        'year-selector': 'year-selector' in d,
        'map-upcoming': 'map-upcoming-preview' in d,
        'connect-btn': 'btn-connect' in d,
        'filter-upcoming-active': 'filter-tab active" data-filter="upcoming"' in d,
    }
    passed = sum(checks.values())
    total = len(checks)
    details = []
    for name, ok in checks.items():
        details.append(f"    {'✅' if ok else '❌'} {name}")
    return f"{passed}/{total} passed\n" + "\n".join(details)
test("HTML Template", f"{BASE}/", check_html)

print("\n=== All tests done ===")
